
let passwordField   =   document.querySelector('form input[type = "password"]#password');
let confirmPasswordField   =   document.querySelector('form input[type = "password"]#confirmpassword');
let iconsList  = document.querySelectorAll('form #passSecure');
console.log(passwordField);
console.log(iconsList)

iconsList[0].addEventListener('click', () => {
    console.log(passwordField)
    if(passwordField.type == 'password'){
        passwordField.type = "text";
        iconsList[0].classList.add = "active";
    }else{
        passwordField.type = "password";
        iconsList[0].classList.remove= "active";
    }
})

//  confirm password
iconsList[1].addEventListener('click', () => {
    console.log(confirmPasswordField)
    if(confirmPasswordField.type == 'password'){
        confirmPasswordField.type = "text";
        iconsList[1].classList.add = "active";
    }else{
        confirmPasswordField.type = "password";
        iconsList[1].classList.remove= "active";
    }
})
