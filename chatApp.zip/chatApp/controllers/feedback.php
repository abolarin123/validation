<?php
    class Feedback
    {
        public $tag;

        public function __construct($tag)
        {
            # code...
            $this->tag = $tag;
        }

        public function SetFeedback()
        {
            # code...
        }

        public function __destruct()
        {
            # code...
            foreach (array_keys($_SESSION) as $key => $value) {
                # code...
                // print($value);
                if ($value == 'success') {
                    # code...
                    if (isset($_SESSION[$this->tag])) {
                        # code...
                        echo '
                        <div class="alert alert-success mt-4 mx-4 alert-dismissible fade show" style="position: absolute; top: 0;" role="alert">
                        <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                          <strong>Great!</strong> '. $_SESSION[$this->tag].'
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        ';
                        unset($_SESSION[$this->tag]);
                    }
                }elseif ($value == 'error') {
                    # code...
                    if (isset($_SESSION[$this->tag])) {
                        # code...
                        echo '
                        <div class="alert alert-danger mt-4 mx-4 alert-dismissible fade show" style="position: absolute; top: 0;" role="alert">
                        <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                          <strong>Oops!</strong> '. $_SESSION[$this->tag].'
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        ';
                        unset($_SESSION[$this->tag]);
                    }
                }elseif ($value == 'info') {
                    # code...
                    if (isset($_SESSION[$this->tag])) {
                        # code...
                        echo '
                        <div class="alert alert-info mt-4 mx-4 alert-dismissible fade show" style="position: absolute; top: 0;" role="alert">
                        <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                          <strong>Info!</strong> '. $_SESSION[$this->tag].'
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        ';
                        unset($_SESSION[$this->tag]);
                    }
                }elseif($value == 'errors') {
                    # code...
                    if (isset($_SESSION[$this->tag])) {
                        # code...
                        echo '
                        <div class="alert alert-danger mt-4 mx-4 alert-dismissible fade show" style="position: absolute; top: 0;" role="alert">
                        <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                          <strong>Oops!</strong>
                        <ul>';
                        foreach ($_SESSION[$this->tag] as $key => $value) {
                            # code...
                            echo '<li>'. $value.'</li>';
                        }
                        echo '</ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>';


                        unset($_SESSION[$this->tag]);
                    }
                }
            }
        }
    }
    
?>