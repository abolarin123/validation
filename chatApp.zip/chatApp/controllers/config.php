<?php
    class DB{
        public $host;
        public $user;
        public $pass;
        public $db;

        function __construct($host, $user, $pass, $db)
        {
            # code...
            $conn   =  new mysqli($host, $user, $pass, $db);
            $this->conn =   $conn;
        }

        function ConnectionDriver()
        {
            # code...
            if ($this->conn->connect_error) {
                # code... 
                die("Connection failed".$this->conn->connect_error);
            }
            return $this->conn;
        }
    }

?>