<?php
class ErrorValidate extends Validate{
    public function fetchError()
    {
        # code...
        // print_r($this->errors);
        $_SESSION['errors'] = $this->errors;
        header("LOCATION:".$_SERVER['HTTP_REFERER']);
        // 
        foreach ($this->errors as $key => $error) {
            # code...
            print($key." : ".$error."<br>");
        }
    }

    public function countError()
    {
        # code...
        return count($this->errors);
    }

    public function Checkerror()
    {
        # code...
        if ($this->countError() > 0) {
            # code...
            
            return true;
        } else {
            # code...
            return false;
        }
        
    }
}
?>