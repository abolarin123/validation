<?php
class Validate{
    public $data;
    public $conn;
    public $errors = [];
    public $title;

    // an array of the posted form
    function __construct($post_data, $db, $title = null)
    {
        # code...
        $this->data =   $post_data;
        $this->conn = $db;
        $this->title = $title;
    }

    // clean up the data comming in
    function clean_input($input = null){
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input);
        $input = $this->conn ->real_escape_string($input);

        $this->clean_input = $input;
    }

    // test for empty fields
    function test_empty($input, $field){
        if (empty($input)) {
            # code...
            $this->add_error($field, "field cannot be empty.");
        }
    }

    // test for email comming
    function valid_email($input, $field){
        if(!filter_var($input, FILTER_VALIDATE_EMAIL)){
            $this->add_error($field, "Oops! Invalid email address.");
        }
    }

    // tested for input length
    function input_length($input, $field)
    {
        # code...
        if (strlen($input) <3) {
            # code...
            $this->add_error($field, "field has too few characters. This field must be atleast greater than 2 characters.");
        }
    }

    // password validation
    function valid_password($input, $field){
        $uppercase      = preg_match('@[A-Z]@', $input);
        $lowercase      = preg_match('@[a-z]@', $input);
        $number         = preg_match('@[0-9]@', $input);
        $specialChars   = preg_match('@[^\w]@', $input);
        if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($input) < 6) {
            $this->add_error($field, 'Password should be at least 6 characters in length and should include at least one upper case letter, one number, and one special character.');
        }
    }

    function add_error($key, $val){
        $this->errors[$key] = $val;
    }

}
?>