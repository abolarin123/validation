<?php
class login{
    public $email, $password, $db;

    public function __construct($connect, $email, $password)
    {
        # code...
        $this->email    =   $email;
        $this->password =   $password;
        $this->db       =   $connect;
    }

    public function AuthenticateUser()
    {
        # code...
        $sql = "SELECT * FROM tbl_users WHERE email = '{$this->email}' AND status = '1'";
        $result =   $this->db->query($sql);
        $countEmail =   mysqli_num_rows($result);
        // check if email exist
        if ($countEmail > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                # code...
                // echo $row['password'];
                if (password_verify($this->password, $row['password'])) {
                    # code...
                    $_SESSION['isLoggedIn'] =   true;
                    $_SESSION['loggedInAt'] =   time();
                    $_SESSION['_token']     =   $row['unique_id'];
                    $_SESSION['user_id']    =   $row['user_id'];
                    $_SESSION['first_name'] =   $row['first_name'];
                    $_SESSION['last_name']  =   $row['last_name'];
                    $_SESSION['email']      =   $row['email'];
                    $_SESSION['status']     =   $row['status'];
                    $_SESSION['created_at'] =   $row['created_at'];
                    $_SESSION['updated_at'] =   $row['updated_at'];
                    $_SESSION['initials']   =   strtoupper(mb_substr($row['last_name'], 0, 1)).strtoupper(mb_substr($row['first_name'], 0, 1));
                } else {
                    # code...
                    $_SESSION['error']  =   "Password is incorrect.";
                    header("LOCATION:".$_SERVER['HTTP_REFERER']);
                }
                
            }

        }else {
            # code...
            $_SESSION['error'] = "This email address has not been registered with us. Kindly visit our signup section to create an account with us.";
            header("LOCATION:".$_SERVER['HTTP_REFERER']);
            // print($_SESSION['error']);
        }
    }

    public function GrantAccess()
    {
        # code...
        if ($_SESSION['isLoggedIn'] == true) {
            # code...
            header("LOCATION: ../views/pages/chat.php");
        } else {
            # code...
            return $this->IsGuest();
        }
        
    }

    public function IsGuest()
    {
        # code...
        header("LOCATION:".$_SERVER['HTTP_REFERER']);
    }
}
?>