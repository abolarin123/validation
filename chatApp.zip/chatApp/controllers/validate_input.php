<?php
class Input extends ErrorValidate{
    public static $fields = [];
    // method to validate form
    public function validate_form()
    {
        # code...
        self::$fields= array_keys($this->data);
        if (in_array($this->title, self::$fields)) {
            # code...
            $key = array_search($this->title, self::$fields);
            unset(self::$fields[$key]);
        }
        foreach(self::$fields as $field){
            // print_r($this->data);
            $value = $this->clean_input($this->data[$field]);
            $value = $this->test_empty($this->data[$field], $field);
            $value = $this->input_length($this->data[$field], $field);

            if ($field == 'email') {
                # code...
                $value = $this->valid_email($this->data[$field], $field);
            }

            if ($field == 'password') {
                # code...
                $value = $this->valid_password($this->data[$field], $field);
            }

            if ($field == 'confirm_password') {
                # code...
                $value = $this->valid_password($this->data[$field], $field);
            }
        }
    }
}
?>