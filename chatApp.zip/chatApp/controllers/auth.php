<?php

    require "session.php";
    require "config.php";
    require "validate.php";
    require "validate_error.php";
    require "validate_input.php";
    require "register.php";
    require "login.php";
    require "feedback.php";
    
    // Csrf token
    $csrf_token = new CSRF_TOKEN_VERIFICATION($_POST['_token']);
    $csrf_token->VerifyToken();

    // db connection driver
    $db =   new DB("localhost", "root", "", "chatapp");
    $connect = $db->ConnectionDriver();

    // regisration process
    if (isset($_POST['register'])) {
        # code...
        
        // validate all input fields.
        $form   = new Input($_POST, $connect, 'register');
        $form->validate_form();

        // returns true if there is an error.
        $checkError =   $form->CheckError();

        if ($checkError== false) {
            # code...
            // check if email exist in users table.
            $sql = "SELECT `email` FROM tbl_users WHERE email = '{$_POST['email']}'";
            $result =   $connect->query($sql);
            $countEmail =   mysqli_num_rows($result);
            // check if email exist
            if ($countEmail > 0) {
                # code...
                $_SESSION['error']  =   "This email is already registered";
                header("LOCATION: ".$_SERVER['HTTP_REFERER']);
            } else {
                # code...

                // this is what is saving all data to db
                $register   =   new Registration($connect);
                $register->CreateNewUser(bin2hex(openssl_random_pseudo_bytes(32)), $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['password']);
                $register->SuccessFeedback();
            }
            
        }elseif ($checkError == true) {
            # code...
            $form->fetchError();
        }
    }

    if (isset($_POST['login'])) {
        # code...
        // validate all input fields.
        $form   = new Input($_POST, $connect, 'login');
        $form->validate_form();

        

        // returns true if there is an error.
        $checkError =   $form->CheckError();

        if ($checkError== false) {
            $login = new login($connect, $_POST['email'], $_POST['password']);
            $login->AuthenticateUser();
            $login->GrantAccess();
        }elseif ($checkError == true) {
            # code...
            // fetches all errors for validation.
            $form->fetchError();
        }
    }

?>