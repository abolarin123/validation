<?php
    session_start();

    // token for csrf_token
    $_SESSION['_token'] =   md5(uniqid(mt_rand(10, 1000), true));

    class CSRF_TOKEN_VERIFICATION{
        public $output;
        public $token;

        public function __construct($token)
        {
            # code...
            $this->token = $token;
        }

        public function VerifyToken()
        {
            # code...
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                # code...
                if (!$this->token || filter_input(INPUT_POST, '_token', FILTER_SANITIZE_STRING) != $this->token) {
                    # code...
                    print $this->output == "419 CROSS ORIGIN"
                    and exit("419 ERROR! BAD REQUEST, THIS REQUEST IS COMING FROM A WRONG ORIGIN.");
                }
            }
        }
    }
?>