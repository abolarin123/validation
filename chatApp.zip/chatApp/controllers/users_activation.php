<?php
  require "session.php";
  require "config.php";
  require "register.php";
  require "feedback.php";

  $db =   new DB("localhost", "root", "", "chatapp");
  $connect = $db->ConnectionDriver();

  if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    # code...
    // get unique id
    $uniqueID = $_GET['token'];
    // echo $uniqueID;
    if (isset($uniqueID) || !empty($uniqueID)) {
      # code...
      $register   =   new Registration($connect);
      $register->ActivateUser($uniqueID);
    }else{
      print("token cannot be empty");
    }

  }
?>