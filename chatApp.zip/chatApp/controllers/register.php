<?php
require "mailer.php";

class Registration{
    public $db;
    public $success;

    public function __construct($db)
    {
        # code...
        $this->db = $db;
        
    }

    public function CreateNewUser($_token, $firstname, $lastname, $email, $password)
    {
        # code...
        // echo "hello";
        $password = password_hash($password, PASSWORD_BCRYPT);
        $sql = "INSERT INTO `tbl_users`(`unique_id`, `first_name`, `last_name`, `email`, `password`, `status`) VALUES ('{$_token}', '{$firstname}', '{$lastname}', '{$email}', '{$password}', '0')";
        if($this->db->query($sql)) {
            //code...
            
            # code...
            try {
                // send verification message
                $name = "{$lastname} {$firstname}";
                $message = "Hi {$lastname} {$firstname}! Account created. Here is the activation link <a href='http://localhost/web/php/chatApp/controllers/users_activation.php?token={$_token}'>Activate Now</a>";
                Mailer($email, $name, 'Activate Account', $message);
    
                $this->success = "Activation email sent";
                $_SESSION['success'] = "Hello {$name}! Your account has been created successfully. Kindly visit your mailbox for activation...";
                header("LOCATION:". $_SERVER['HTTP_REFERER']);
            } catch (\Throwable $th) {
                throw $th;
                $_SESSION['error'] = "Oops! could not create new user";
                header("LOCATION:". $_SERVER['HTTP_REFERER']);
            }
            
        } else {
            //throw $th;
            $_SESSION['error'] = "Problem adding user.".$this->db->error."=".$sql;
            header("LOCATION:". $_SERVER['HTTP_REFERER']);
        }
        
    }

    public function ActivateUser($id)
    {
        # code...
        $sql = "SELECT email from tbl_users WHERE `unique_id` = '{$id}'";
        if (mysqli_num_rows($this->db->query($sql))>0) {
            # code...
            $sql = "UPDATE tbl_users SET `status` = '1' WHERE `unique_id` = '{$id}'";
            try {
                //code...
                $this->db->query($sql);
                $_SESSION['success'] = "Activated new user successfully";
                header("LOCATION: ../views/auth/login.php");
            } catch (\Throwable $th) {
                //throw $th;
                $_SESSION['error'] = "Problem activating user.";
                header("LOCATION:". $_SERVER['HTTP_REFERER']);
            }
        }else{
            print "Activation failed due to wrong token id";
        }
    }

    public function SuccessFeedback()
    {
        # code...
        return "Activation link sent to your email address. Kindly check your inbox to activate your account.";
    }
}
?>