<?php
// include packages and file for php mailer and smtp protocols
    require 'phpmailer/Exception.php';
    require 'phpmailer/PHPMailer.php';
    require 'phpmailer/SMTP.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
    
    function Mailer($email, $name, $subj, $msg)
    {
        # code...
        $mail = new PHPMailer(true);
        $mail->IsSMTP();
        $mail->Mailer = "smtp";
        $mail->Host       = "smtp.gmail.com";
        $mail->SMTPAuth   = TRUE;
        $mail->SMTPSecure = "ssl";
        $mail->Port       = 465;
        $mail->Username   = "abolarinbabatunde88@gmail.com";
        $mail->Password   = "tytxbarbsjwykyax";

        $mail->isHTML(true);
        $mail->Subject = $subj;
        $mail->SetFrom("abolarinbabatunde88@gmail.com");
        $mail->Body = $msg;
        $mail->AddAddress($email);
        if ($mail->Send()) {
            # code...
            echo "Email sent successfully...";
        } else {
            # code...
            echo "Message not sent";
            var_dump($mail);
        }
        $mail->smtpClose();

    }
?>