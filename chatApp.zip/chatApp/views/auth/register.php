<?php
  require_once "../../controllers/session.php";
  require_once "../../controllers/feedback.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php require('../components/style.php'); ?>
    <style>
    .background-radial-gradient {
      background-color: hsl(218, 41%, 15%);
      background-image: radial-gradient(650px circle at 0% 0%,
          hsl(218, 41%, 35%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%),
        radial-gradient(1250px circle at 100% 100%,
          hsl(218, 41%, 45%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%);
    }

    #radius-shape-1 {
      height: 220px;
      width: 220px;
      top: -60px;
      left: -130px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    #radius-shape-2 {
      border-radius: 38% 62% 63% 37% / 70% 33% 67% 30%;
      bottom: -60px;
      right: -110px;
      width: 300px;
      height: 300px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    .bg-glass {
      background-color: hsla(0, 0%, 100%, 0.9) !important;
      backdrop-filter: saturate(200%) blur(25px);
    }
  </style>

</head>
<body>
    <!-- Section: Design Block -->
<section class="background-radial-gradient overflow-hidden">
            <?php 
              $errors = new Feedback("errors");
              $error = new Feedback("error");
              $success = new Feedback("success");
            ?>
  <div class="container px-4 py-5 px-md-5 text-center text-lg-start my-5">
    <div class="row gx-lg-5 align-items-center mb-5">
      <div class="col-lg-6 mb-5 mb-lg-0" style="z-index: 10">
        <h1 class="my-5 display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 95%)">
          The best offer <br />
          <span style="color: hsl(218, 81%, 75%)">for your business</span>
        </h1>
        <p class="mb-4 opacity-70" style="color: hsl(218, 81%, 85%)">
          Looking for a platform to communicate perfectly well to your team? Here in mongoose we offer the best platform for interactive business. Knowing fully well that you value productivity. Your suceess, our interest.
        </p>
      </div>

      <div class="col-lg-6 mb-5 mb-lg-0 position-relative">
        <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
        <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>

        <div class="card bg-glass">
          <div class="card-body px-4 py-5 px-md-5">
          
            <form method = "post" action="../../controllers/auth.php">
            
              <!-- 2 column grid layout with text inputs for the first and last names -->
              <?php require "../components/csrf_token.php"; ?>
              <div class="row">
                <div class="col-md-6 mb-4">
                  <div class="form-floating">
                    <input type="text" name='first_name' placeholder="First name" id="form3Example1" class="form-control" />
                    <label class="form-label" for="form3Example1">First name</label>
                  </div>
                </div>
                <div class="col-md-6 mb-4">
                  <div class="form-floating">
                    <input type="text" name='last_name' placeholder="Last name" id="form3Example2" class="form-control" />
                    <label class="form-label" for="form3Example2">Last name</label>
                  </div>
                </div>
              </div>

              <!-- Email input -->
              <div class="form-floating mb-4">
                <input type="email" name='email' id="form3Example3" placeholder="Email address" class="form-control" />
                <label class="form-label" for="form3Example3">Email address</label>
              </div>

              <!-- Password input -->
              <?php include('../components/password.php'); ?>

              <!-- Password input -->
              
              <div class="form-floating mb-4 custom-password">
                <input type="password" name='confirm_password' placeholder="Confirm Password" id="confirmpassword" class="form-control" />
                <label class="form-label" for="form3Example4">Confirm password</label>
                <i class="fa fa-eye" id="passSecure" style="position: absolute; right: 17px; top: 40%; color: #ccc;"></i>
              </div>
              

              <!-- Checkbox -->
              <div class="form-check d-flex justify-content-center mb-4">
                <input class="form-check-input me-2" type="checkbox" value="" id="form2Example33" checked />
                <label class="form-check-label" for="form2Example33">
                  Subscribe to our newsletter
                </label>
              </div>

              <!-- Submit button -->
              <div class="d-grid">
              <button type="submit" name="register" class="btn btn-primary text-center btn-block mb-4">
                Sign up
              </button>
              </div>

              <!-- Register buttons -->
              <div class="text-center">
                <p>or sign up with:</p>
                <button type="button" class="btn btn-link btn-floating mx-1">
                  <i class="fab fa-facebook-f"></i>
                </button>

                <button type="button" class="btn btn-link btn-floating mx-1">
                  <i class="fab fa-google"></i>
                </button>

                <button type="button" class="btn btn-link btn-floating mx-1">
                  <i class="fab fa-twitter"></i>
                </button>

                <button type="button" class="btn btn-link btn-floating mx-1">
                  <i class="fab fa-github"></i>
                </button>
              </div>
              <div class="text-center mt-5">
                <p class="mb-0">Already have an account? <a href="login.php" class="text-dark-50 fw-bold">Sign In</a>
                </p>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Section: Design Block -->
<?php require('../components/jScript.php'); ?>
</body>
</html>