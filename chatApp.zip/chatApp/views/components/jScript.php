<script src="../../assets/js/bootstrap.js"></script>
<script src="../../assets/js/password.js"></script>