<div class="form-floating mb-4" id="password">
    <input type="password" name='password' placeholder="Password" id="password" class="form-control" />
    <label class="form-label" for="form3Example4">Password</label>
    <i class="fa fa-eye active" id="passSecure" style="position: absolute; right: 17px; top: 40%; color: #ccc;"></i>
</div>